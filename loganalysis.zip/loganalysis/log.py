#!/usr/bin/env python
import psycopg2
import os
import sys

__author__ = "Enas Abdelabi"
__version__ = '0.1'


def popularArticles():
    finalRes = []
    conn = psycopg2.connect('dbname =news')
    c = conn.cursor()
    Articles = """
               SELECT articles.title,count(log.ip) AS views
               FROM og JOIN articles
               ON log.path = CONCAT('/article/', articles.slug)
               GROUP BY articles.title
               ORDER BY views DESC 
               LIMIT 3;"""
    c.execute(Articles)
    result = c.fetchall()
    conn.close()
    for article in result:
        title = "'{}" >>>>>> {} views' .format( str(article[0]),str(article[1]) 
        finalRes.append(title)
    return finalRes


def popularAuthors():
    finalRes = []
    conn = psycopg2.connect('dbname =news')
    c = conn.cursor()
    Authors = """
              SELECT authors.name, count(log.ip) AS views
              FROM log,authors,articles
              WHERE articles.author = authors.id 
              and CONCAT('/article/',articles.slug) = log.path 
              GROUP BY authors.name
              ORDER BY views DESC;"""
    c.execute(Authors)
    result = c.fetchall()
    conn.close()
    for author in result:
        auth =   '"{}" >>>>>> {} views' .format( str(author[0]),str(author[1]))
        finalRes.append(auth)
    return finalRes


def Dayserror():
    finalRes = []
    conn = psycopg2.connect('dbname =news')
    c = conn.cursor()
    Days = """
         SELECT to_char(date,'FMDD FMMonth YYYY'),round((error::numeric/total)*100,2)
         AS rat 
        FROM (SELECT time::date AS date, count(*) AS total ,
        SUM((status != '200 OK')::int)::float AS error FROM log
        GROUP By date) AS errors
        WHERE error/total > 0.01;"""
    c.execute(Days)
    result = c.fetchall()
    conn.close()
    for day in result:
        rat = '"{}" >>>>>> {} ' .format(str(day[0]),str(round(day[1],2 ))) + " %  views"
        finalRes.append(rat)
    return finalRes

if __name__ == '__main__':
    
    outputfile = open('outputs.txt', 'w')
    print("\nThe most popular 3 articles\n ")
    outputfile.write("\nThe most popular 3 articles\n ")
    finalRes = popularArticles()
    for title in finalRes:
        print(title)
        outputfile.write(title)
    print("\nThe most popular Authors\n")
    outputfile.write("\nThe most popular Authors\n")
    finalRes = popularAuthors()
    for auth in finalRes:
        print(auth)
        outputfile.write(auth)
    print("\nThe days of error\n")
    outputfile.write("\nThe days of error\n")
    finalRes = Dayserror()
    for rat in finalRes:
        print(rat)
        outputfile.write(rat)
    print()
    outputfile.write('\n')
    outputfile.close()


main()
