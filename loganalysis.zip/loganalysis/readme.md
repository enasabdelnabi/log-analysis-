# internal reporting tool

## objective:-
stretch my SQL database skills. i will get practice interacting with a live database both from the command line and from my code
the code displays the correct answers to each of the questions in the project description.
####Description:
his project sets up a mock PostgreSQL database for a fictional news website. The provided Python script uses the psycopg2 library to query the database and produce a report that answers the following three questions:
#####What are the most popular three articles of all time?
**Ex))  Output:**
1-Candidate is jerk, alleges rival>>>>>>338647 view
2-Bears love berries, alleges bear>>>>>>253801 view
3-Bad things gone, say good people>>>>>>170098 view

#####Who are the most popular article authors of all time? 
**EX)) output:- **
1-Ursula La Multa---> 507594 view
2-Rudolf von Treppenwitz---> 423457 view
3-Anonymous Contributor---> 170098 view
4-Markoff Chaney---> 84557 view
#####On which days did more than 1% of requests lead to errors?
**Ex))Output: **-
 17 July 2016........2.3 %
 
###prepare the software :
Install virtualbox 

https://l.facebook.com/l.php?u=https%3A%2F%2Fwww.virtualbox.org%2Fwiki%2FDownload_Old_Builds_5_1%3Ffbclid%3DIwAR2S1bEIWgXIvJELMQXyM_bZ3YL3PotcLQPj86fOsqaKzhMVkWjfhhrsMyc&h=AT1Lm3WZ6CkNYlksKw6QUVgpBubPNL29Mme8sm9-9b1l5KG4JLzYHP6diLjwVa9vBb1XGQyIx0aaon8-5pXgNCq9ow1srtazjSJwXE3jwM0NyE25pyWMOuMPhJ3WVaOUtjvG
Install vagrant 

https://l.facebook.com/l.php?u=https%3A%2F%2Freleases.hashicorp.com%2Fvagrant%2F%3Ffbclid%3DIwAR35q7svzuimvCIvemLVOZBgpC2dVl7Rif0ix1v_FGYt_HcYMGveCewZmWg&h=AT1Lm3WZ6CkNYlksKw6QUVgpBubPNL29Mme8sm9-9b1l5KG4JLzYHP6diLjwVa9vBb1XGQyIx0aaon8-5pXgNCq9ow1srtazjSJwXE3jwM0NyE25pyWMOuMPhJ3WVaOUtjvG
Then, open git bash and execute  the command lines 
 ( gitbash whe usig windos but linux and mac will open termial bulit in)
Vagrant up 
Vagrant ssh 
here , is example for vagrantfile https://github.com/udacity/fullstack-nanodegree-vm/blob/master/vagrant/Vagrantfile
##Prepare the data
download the date from here https://d17h27t6h515a5.cloudfront.net/topher/2016/August/57b5f748_newsdata/newsdata.zip
Execute these command on gitbash
To load the data,   newsdata.sql
 cd into the vagrant directory and use the command psql -d news -f newsdata.sql.
##the database includes three tables:

1-The authors table includes information about the authors of articles.
2-The articles table includes the articles themselves.
-3-The log table includes one entry for each time a user has accessed the site.


**Connection **
db = psycopg2.connect("dbname=news")

**RUN**
execute this command if you use python2.7
 $ python log.py
